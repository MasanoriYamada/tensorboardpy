# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tensorboardpy']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.3.2,<2.0.0', 'tensorboard>=2.6.0,<3.0.0']

setup_kwargs = {
    'name': 'tensorboardpy',
    'version': '0.1.0',
    'description': 'Create a pandas dataframe from the tensorboard log!',
    'long_description': None,
    'author': 'MasanoriYamada',
    'author_email': 'yamada0224@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
